﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

// we make class for player to choose either he take X or O
[System.Serializable]
public class player
{
	public Image panel;
	public Text text;
	public Button button; // aftr lec 11 
}

// For active & Inactive color scheme after making xclasses these are not view in game so for serializing them 
// we use seriallizable attribute
[System.Serializable]
public class playerColor
{

	public Color PannelColor;
	public Color TextColor;
}
	


public class GameController : MonoBehaviour {

	public Text[] buttonList;
	//private string playerside;
	public GameObject gameOverPannel;
	public Text gameOverText;

	// now we need two new instance of player & two new for color

	public player PlayerX;
	public player PlayerO;
	public playerColor activePlayerColor;
	public playerColor inactivePlayerColor;

	private int moveCount;
	public GameObject RestartButton;  // buton for ui
	public GameObject StartInfo;  // in lec 11 for choosing one side

	private string playerside;  // shift from 30 line
	private string ComputerSide;
	public bool playerMove;
	public float delay;
	private int value;
	public bool TwoPlayer;

	void Awake ()
	{
		gameOverPannel.SetActive (false);
		SetGameControllerRefOnButton();
		//playerside = "X";  // at 11 lec we remove both setplayercolor for choice form user
		moveCount = 0;
		RestartButton.SetActive (false);
		//SetPlayerColors (PlayerX , PlayerO);  // at 11 lec we remove both setplayercolor for choice form user

		TwoPlayer = true;
	}

	// The Update is for getting move to computer side after player move

	/// <summary>
	/// Update this instance.
	/// </summary>ll...........................................
	///



	void Update ()

	{
		if (TwoPlayer == false) 
		{
		if (playerMove == false) 
		{
			delay += delay * Time.deltaTime;

			if (delay >= 100)
			{

				value = Random.Range (0, 8);
				if (buttonList [value].GetComponentInParent<Button> ().interactable == true)
				{

					buttonList [value].text = GetComputerSide ();
					buttonList [value].GetComponentInParent<Button> ().interactable =false;
					EndTurn ();
				}
			}
		}



		}  }



	// for setting the choice of player 

	public void SetStartingSide(string StartingSide)

	{	// for two player mode 
		if(TwoPlayer == true)
			
		{
			playerside = StartingSide;

			if (playerside == "X") 
			{	
				//ComputerSide = "O";
				SetPlayerColors (PlayerX, PlayerO);

			}
			else
			{
				//ComputerSide = "X";
				SetPlayerColors (PlayerO, PlayerX);
			}

			StartGame ();

		}

		else{
			playerside = StartingSide;

			if (playerside == "X") {	
				ComputerSide = "O";
				SetPlayerColors (PlayerX, PlayerO);
		
			} else {
				ComputerSide = "X";
				SetPlayerColors (PlayerO, PlayerX);
			}

			StartGame (); }
	}

	// after lec 11
	/// <summary>
	/// Starts the game.
	/// </summary>
	void StartGame()
	{
		SetBoardInteractable (true);
		SetPlayerButtons(false);
		StartInfo.SetActive (false);
	}

	/// <summary>
	/// Sets the game controller reference on button.
	/// </summary>
	public void SetGameControllerRefOnButton ()
	{
		for (int i = 0; i < buttonList.Length; i++)
		{
			buttonList [i].GetComponentInParent<GRIDSPACE1> ().SetGameControllerRef(this);


		}
	}

	// For Getting player Side
	/// <summary>
	/// Gets the player side.
	/// </summary>
	/// <returns>The player side.</returns>

	public string GetPlayerSide()
	{
		return playerside;
	}

	/// <summary>
	/// Gets the computer side.
	/// </summary>
	/// <returns>The computer side.</returns>
	public string GetComputerSide()
	{
		return ComputerSide;
	}

	/// <summary>
	/// Ends the turn.
	/// </summary> this function tells who wans the game 

	public void EndTurn()
		{
		if (TwoPlayer == true) {
			moveCount++;
			//Debug.Log ("EndTurn is not implemented !");

			if (buttonList [0].text == playerside && buttonList [1].text == playerside && buttonList [2].text == playerside) 
			{
				GameOver (	playerside);
			}
			// since when we win game then last turn is shaded but the the game is wined so this is due to
			// change side function so we use else if & changes all 8 if to else if or move also is else
			else if (buttonList [3].text == playerside && buttonList [4].text == playerside && buttonList [5].text == playerside) 
			{
				GameOver (playerside);
			}

			else if (buttonList [6].text == playerside && buttonList [7].text == playerside && buttonList [8].text == playerside) 
			{
				GameOver (playerside);
			}

			else if (buttonList [0].text == playerside && buttonList [3].text == playerside && buttonList [6].text == playerside) 
			{
				GameOver (playerside);
			}

			else if (buttonList [1].text == playerside && buttonList [4].text == playerside && buttonList [7].text == playerside) 
			{
				GameOver (playerside);
			}

			else if (buttonList [2].text == playerside && buttonList [5].text == playerside && buttonList [8].text == playerside) 
			{
				GameOver (playerside);
			}

			else if (buttonList [0].text == playerside && buttonList [4].text == playerside && buttonList [8].text == playerside) 
			{
				GameOver (playerside);
			}

			else if (buttonList [2].text == playerside && buttonList [4].text == playerside && buttonList [6].text == playerside) 
			{
				GameOver (playerside);
			}

			else if (buttonList [0].text == playerside && buttonList [1].text == playerside && buttonList [2].text == playerside) 
			{
				GameOver (playerside);
			}


			else if (moveCount >= 9) 
			{
				//gameOverPannel.SetActive (true);
				//SetGameOVerText( " It's A DRAW ! ");
				GameOver("It's A DRAW !");

			}

			// for chamging the X or in alternate we use inline fun of change side
			else 
			{
				ChangeSide ();
				//delay = 10;
			}

		} 

		else
		{
			moveCount++;

			if (buttonList [0].text == playerside && buttonList [1].text == playerside && buttonList [2].text == playerside) 
			{
				GameOver (	playerside);
			}
			// since when we win game then last turn is shaded but the the game is wined so this is due to
			// change side function so we use else if & changes all 8 if to else if or move also is else
			else if (buttonList [3].text == playerside && buttonList [4].text == playerside && buttonList [5].text == playerside) 
			{
				GameOver (playerside);
			}

			else if (buttonList [6].text == playerside && buttonList [7].text == playerside && buttonList [8].text == playerside) 
			{
				GameOver (playerside);
			}

			else if (buttonList [0].text == playerside && buttonList [3].text == playerside && buttonList [6].text == playerside) 
			{
				GameOver (playerside);
			}

			else if (buttonList [1].text == playerside && buttonList [4].text == playerside && buttonList [7].text == playerside) 
			{
				GameOver (playerside);
			}

			else if (buttonList [2].text == playerside && buttonList [5].text == playerside && buttonList [8].text == playerside) 
			{
				GameOver (playerside);
			}

			else if (buttonList [0].text == playerside && buttonList [4].text == playerside && buttonList [8].text == playerside) 
			{
				GameOver (playerside);
			}

			else if (buttonList [2].text == playerside && buttonList [4].text == playerside && buttonList [6].text == playerside) 
			{
				GameOver (playerside);
			}

			else if (buttonList [0].text == playerside && buttonList [1].text == playerside && buttonList [2].text == playerside) 
			{
				GameOver (playerside);
			}

			//// for cheking either the computer wins we paste tyhe same code of end for computer
			/// and change player side to computer side
			/// 

			else if (buttonList [0].text == playerside && buttonList [1].text == playerside && buttonList [2].text == playerside) 
			{
				GameOver (ComputerSide);
			}
			// since when we win game then last turn is shaded but the the game is wined so this is due to
			// change side function so we use else if & changes all 8 if to else if or move also is else
			else if (buttonList [3].text == playerside && buttonList [4].text == playerside && buttonList [5].text == playerside) 
			{
				GameOver (ComputerSide);
			}

			else if (buttonList [6].text == playerside && buttonList [7].text == playerside && buttonList [8].text == playerside) 
			{
				GameOver (ComputerSide);
			}

			else if (buttonList [0].text == playerside && buttonList [3].text == playerside && buttonList [6].text == playerside) 
			{
				GameOver (ComputerSide);
			}

			else if (buttonList [1].text == playerside && buttonList [4].text == playerside && buttonList [7].text == playerside) 
			{
				GameOver (ComputerSide);
			}

			else if (buttonList [2].text == playerside && buttonList [5].text == playerside && buttonList [8].text == playerside) 
			{
				GameOver (ComputerSide);
			}

			else if (buttonList [0].text == playerside && buttonList [4].text == playerside && buttonList [8].text == playerside) 
			{
				GameOver (ComputerSide);
			}

			else if (buttonList [2].text == playerside && buttonList [4].text == playerside && buttonList [6].text == playerside) 
			{
				GameOver (ComputerSide);
			}

			else if (buttonList [0].text == playerside && buttonList [1].text == playerside && buttonList [2].text == playerside) 
			{
				GameOver (ComputerSide);
			}


			// for checking drawn we use draw function

			else if (moveCount >= 9) 
			{
				//gameOverPannel.SetActive (true);
				//SetGameOVerText( " It's A DRAW ! ");
				GameOver("It's A DRAW !");

			}

			// for chamging the X or in alternate we use inline fun of change side
			else 
			{
				ChangeSide ();
				delay = 10;
			}

		}
	}

	/// <summary>
	/// Games the over.
	/// </summary>
	/// <param name="winningPlayer">Winning player.</param>
	public void GameOver (string winningPlayer)

	{
		if (winningPlayer == "Draw") 
		{
			SetGameOVerText ("It's A Draw");
			SetPlayerColorsInactive ();
		} 

		else
		{
			SetGameOVerText (winningPlayer + " WINS !");

		}
		/*for (int i = 0; i < buttonList.Length; i++) 
		{
		
			buttonList [i].GetComponentInParent<Button> ().interactable = false;
		} */
		//gameOverPannel.SetActive (true);
		//gameOverText.text = playerside + " WINS !" ; replace with setGameOver

		//SetBoardInteractable (false);

		//SetGameOVerText (playerside + " WINS !");
		RestartButton.SetActive (true);
	
	}

	/// <summary>
	/// Sets the game O ver text.
	/// </summary>
	/// <param name="value">Value.</param>

	public void SetGameOVerText(string value)
	{
		gameOverPannel.SetActive (true);
		gameOverText.text = value;
	}

	/// <summary>
	/// Changes the side.
	/// </summary>
	public void ChangeSide ()
	{
		if (TwoPlayer== true)
		{
			playerside = (playerside == "X") ? "O" : "X" ;

			// for player move from computer side if player move == true then it in line is true otherwise false
			//playerMove = (playerMove == true) ? false : true;

			// for gining side by side of X and O

			if (playerside == "X") 
			//if(playerMove == true) // for computer play
			{

				SetPlayerColors (PlayerX, PlayerO);
			}
			else 
			{
				SetPlayerColors (PlayerO, PlayerX);	

			}

		}

		else {
		//playerside = (playerside == "X") ? "O" : "X" ;

		// for player move from computer side if player move == true then it in line is true otherwise false
		playerMove = (playerMove == true) ? false : true;

		// for gining side by side of X and O

		//if (playerside == "X") 
		if(playerMove == true) // for computer play
		{
		
			SetPlayerColors (PlayerX, PlayerO);
		}
		else 
		{
			SetPlayerColors (PlayerO, PlayerX);	
		
		}
	}

			}
	//for color of players active & in active

	/// <summary>
	/// Sets the player colors.
	/// </summary>
	/// <param name="newPlayer">New player.</param>
	/// <param name="oldPlayer">Old player.</param>

	void SetPlayerColors(player newPlayer , player oldPlayer)
	{
		newPlayer.panel.color = activePlayerColor.PannelColor;
		newPlayer.text.color = activePlayerColor.TextColor;
		oldPlayer.panel.color = inactivePlayerColor.PannelColor;
		oldPlayer.text.color = inactivePlayerColor.TextColor;

	}

	/// <summary>
	/// Restarts the game.
	/// </summary>

	public void RestartGame()
	{
		moveCount = 0;
		//playerside = "X"; // after 11 lec input select form user we remove that
		gameOverPannel.SetActive (false);

		//SetBoardInteractable (true); // remove after lec 11
		SetPlayerButtons(true);
		SetPlayerColorsInactive (); // after lec 11
		//SetPlayerColorsActive();

		//SetPlayerColors (PlayerX , PlayerO); // after 11 lec input select form user we remove that

		StartInfo.SetActive (true);
		playerMove = true; // for AI of computer side we true that
		delay = 10;

		for (int i = 0; i < buttonList.Length; i++) 
		{

		//	buttonList [i].GetComponentInParent<Button> ().interactable = true;
			buttonList [i].text = " ";
		}

		RestartButton.SetActive (false);


	}

	void SetBoardInteractable (bool toogle)
	{
		for (int i = 0; i < buttonList.Length; i++) {

			buttonList [i].GetComponentInParent<Button> ().interactable = toogle;
		}
	
		RestartButton.SetActive (false);
	}

		// after lec 11

		void SetPlayerButtons(bool toogle)
		{

		PlayerX.button.interactable = toogle;
		PlayerO.button.interactable = toogle;

		}

	void SetPlayerColorsInactive()
	{
		PlayerX.panel.color = inactivePlayerColor.PannelColor;
		PlayerX.text.color = inactivePlayerColor.TextColor;
		PlayerO.panel.color = inactivePlayerColor.PannelColor;
		PlayerO.text.color = inactivePlayerColor.TextColor;

	}

	void SetPlayerColorsActive()
	{
		PlayerX.panel.color = activePlayerColor.PannelColor;
		PlayerX.text.color = activePlayerColor.TextColor;
		PlayerO.panel.color = activePlayerColor.PannelColor;
		PlayerO.text.color = activePlayerColor.TextColor;
	}

	public void TwoPlayerOn()
	{
		TwoPlayer = false; 
	}


	}


