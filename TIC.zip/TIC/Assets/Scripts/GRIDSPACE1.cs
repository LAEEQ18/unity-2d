﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GRIDSPACE1 : MonoBehaviour {

	public Button button;
	public Text buttonText;
	//public string playerside; // it is used in starting 

	private GameController gameController;


	public void SetSpace ()
	{
		// 1stly we use that 
		//buttonText.text = playerside;

		if (gameController.playerMove == true) {  // for Ai of computer side we put that in fuction

			// but for getting which sumbol seclectd by player we use 
			Debug.Log ("Hi" + gameController.GetPlayerSide ());
			buttonText.text = gameController.GetPlayerSide ();
			button.interactable = false;
			gameController.EndTurn ();
		} else
		{
			// but for getting which sumbol seclectd by player we use 
			//Debug.Log ("Hi" + gameController.GetPlayerSide ());
			buttonText.text = gameController.GetPlayerSide ();
			button.interactable = false;
			gameController.EndTurn ();

		}
	}

	public void SetGameControllerRef(GameController controller )
	{
		gameController = controller;
	
	}


}
